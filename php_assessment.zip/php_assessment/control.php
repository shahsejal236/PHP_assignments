<?php


include_once('model.php');
class control extends model
{
        function __construct()
		{
			session_start();
			model::__construct();

			$path=$_SERVER['PATH_INFO'];

			switch ($path)
			
		     
			 {
				case '/index':
					include_once('index.php');
					break;

				case '/index2':
					
						include_once('index2.php');
						break;

				
						
				case '/serach_fruit':
					$fruit_arr=$this->select('fruits');

							include_once('serach_fruit.php');
							break;

				case '/viewfruit':
					$fruit_arr=$this->select('fruits');

								include_once('viewfruit.php');
								break;

				case '/edit_fruit':
					include_once('edit_fruit.php');
									break;

				case '/change_pass':
					include_once('change_pass.php');
					break;
				
				case '/forms':
					if(isset($_REQUEST['submit']))
				{
					$fruit_name=$_REQUEST['fruit_name'];
                    $quantity=$_REQUEST['quantity'];
                	$price=$_REQUEST['price'];

					date_default_timezone_set('asia/calcutta');
				    $created_at=date('Y-m-d H:i:s');
				    $upadte_at=date('Y-m-d H:i:s');

					$arry=array("fruit_name"=>$fruit_name,"quantity"=>$quantity,"price"=>$price,"created_at"=>$created_at,"upadte_at"=>$upadte_at);
                    $res=$this->insert('fruits',$arry);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('Fruits id add');
                        window.location='forms';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "
						<script>
                        alert('Fruits id  not add');
                        window.location='index';
                        </script>
						";
                    }
                }
				
						include_once('forms.php');
						break;
						case'/delete':
							if(isset($_REQUEST['del_fruit_id'])){
								$id=$_REQUEST['del_fruit_id'];
								$where=array("id"=>$id);
								$res=$this->delete_where('fruits',$where);
								if($res){
									echo"
									<script>
									alert('delete sucess');
									window.location='viewfruit';
									</script>
									";
								}else{
									echo"fail";
								}

							}
							break;
							case'/edit':
								if(isset($_REQUEST['edit_fruit_id'])){
									$id=$_REQUEST['edit_fruit_id'];
									$where=array("id"=>$id);
									$res=$this->select_where('fruits',$where);
									
									$fetch=$res->fetch_object();
									
									if(isset($_REQUEST['submit'])){
										$fruit_name=$_REQUEST['fruit_name'];
										$quantity=$_REQUEST['quantity'];
										$price=$_REQUEST['price'];
									
										date_default_timezone_set('asia/calcutta');
				                     $created_at=date('Y-m-d H:i:s');
				                      $upadte_at=date('Y-m-d H:i:s');
									  $arr=array("fruit_name"=>$fruit_name,"quantity"=>$quantity,"price"=>$price);
									  $res=$this->update('fruits',$arr,$where);
									  if($res){
										echo"
										<script>
										alert('update sucess');
										window.location='viewfruit';
										</script>
										";
									  }else{
										echo"
										<script>
										alert('update fail');
										window.location='viewfruit';
										</script>
										";
									  }
  
									}
									
									


									
								}
								include_once('editfruit.php');
                                    break;


					
							default:
			echo "<h1>Page Not Found</h1>";
			break;
		}
	
		}
	}	

$obj=new control;
?>